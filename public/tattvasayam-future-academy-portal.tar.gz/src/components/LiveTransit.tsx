import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Bus,
  MapPin,
  Navigation,
  Clock,
  Radio,
  ShieldCheck,
  Activity,
  Play,
  Pause,
  RotateCcw,
  Gauge,
  Phone,
  CheckCircle2,
  Users,
  AlertCircle,
  Zap,
  Info,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { BusRouteInfo, BusStop } from '../types';

interface LiveTransitProps {
  busRoute?: BusRouteInfo;
  isDark?: boolean;
  onNavigateToParentPortal?: () => void;
}

// Stop coordinates along the SVG canvas (viewBox 0 0 900 480)
interface RouteWaypoint {
  id: number;
  name: string;
  shortName: string;
  landmark: string;
  x: number;
  y: number;
  timeScheduled: string;
  studentsBoarding: string[];
  zone: string;
}

const WAYPOINTS: RouteWaypoint[] = [
  {
    id: 1,
    name: 'Yelahanka Satellite Town (4th Phase)',
    shortName: 'Yelahanka 4th Phase',
    landmark: 'Near NES Circle / Mother Dairy',
    x: 110,
    y: 85,
    timeScheduled: '07:20 AM',
    studentsBoarding: ['Ananya Sharma (Gr 9)', 'Aditya Rao (Gr 11)'],
    zone: 'Zone North-A',
  },
  {
    id: 2,
    name: 'Judicial Layout Gate',
    shortName: 'Judicial Layout',
    landmark: 'GKVK Campus Perimeter Cross',
    x: 275,
    y: 155,
    timeScheduled: '07:35 AM',
    studentsBoarding: ['Meera Sen (Gr 9)', 'Kabir Joshi (Gr 7)'],
    zone: 'Zone North-B',
  },
  {
    id: 3,
    name: 'Sahakar Nagar Main Cross',
    shortName: 'Sahakar Nagar',
    landmark: '14th Main Commercial Junction',
    x: 450,
    y: 220,
    timeScheduled: '07:50 AM',
    studentsBoarding: ['Krishvika (Gr 8-B)', 'Rohan Iyer (Gr 10)'],
    zone: 'Zone Central-East',
  },
  {
    id: 4,
    name: 'Amruthahalli Signal Junction',
    shortName: 'Amruthahalli Signal',
    landmark: 'Bellary Road Underpass Flyover',
    x: 620,
    y: 295,
    timeScheduled: '08:05 AM',
    studentsBoarding: ['Vivan (Gr 10-A)', 'Arjun Verma (Gr 10-A)'],
    zone: 'Zone Jakkur Corridor',
  },
  {
    id: 5,
    name: 'Tattvasayam Future Academy (Gate 2)',
    shortName: 'Campus Gate 2 Turnstile',
    landmark: 'Jakkur Plantation Road • Gate 2 Drop Zone',
    x: 790,
    y: 395,
    timeScheduled: '08:18 AM',
    studentsBoarding: ['All 28 Disembarking Scholars'],
    zone: 'Academy Campus Zone',
  },
];

// Smooth SVG path curve through the 5 waypoints
const ROUTE_SVG_PATH =
  'M 110,85 C 175,95 210,135 275,155 C 345,180 395,200 450,220 C 515,245 565,270 620,295 C 685,330 730,360 790,395';

export const LiveTransit: React.FC<LiveTransitProps> = ({
  busRoute,
  isDark = false,
  onNavigateToParentPortal,
}) => {
  // Current route details with safe fallback
  const route = useMemo<BusRouteInfo>(() => {
    return (
      busRoute || {
        routeNumber: 'Route 14',
        routeName: 'North Bengaluru Express • Yelahanka – Jakkur',
        driverName: 'Mr. Manjunath Gowda',
        driverPhone: '+91 98450 44210',
        vehicleNumber: 'KA-04-FA-2026',
        currentSpeedKmH: 34,
        currentLocationName: 'Approaching Sahakar Nagar 14th Main',
        nextStop: 'Sahakar Nagar Main Cross',
        liveStatus: 'ON_SCHEDULE',
        stops: [
          { name: 'Yelahanka Satellite Town 4th Phase', timeScheduled: '07:20 AM', eta: 'Departed', status: 'passed' },
          { name: 'Judicial Layout Gate', timeScheduled: '07:35 AM', eta: 'Departed', status: 'passed' },
          { name: 'Sahakar Nagar Main Cross', timeScheduled: '07:50 AM', eta: '07:49 AM', status: 'current' },
          { name: 'Amruthahalli Signal', timeScheduled: '08:05 AM', eta: '08:06 AM', status: 'upcoming' },
          { name: 'Tattvasayam Future Academy, Gate 2', timeScheduled: '08:18 AM', eta: '08:18 AM', status: 'upcoming' },
        ],
      }
    );
  }, [busRoute]);

  // Simulation state: progress along path (0.0 to 1.0)
  // Default start around 0.48 (near Sahakar Nagar)
  const [progress, setProgress] = useState(0.48);
  const [isPlaying, setIsPlaying] = useState(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<1 | 2 | 4>(1);
  const [selectedWaypoint, setSelectedWaypoint] = useState<RouteWaypoint | null>(WAYPOINTS[2]);
  const [direction, setDirection] = useState<'inbound' | 'outbound'>('inbound');
  const [telemetryPulse, setTelemetryPulse] = useState(0);

  const pathRef = useRef<SVGPathElement | null>(null);

  // Animation loop simulating live GPS coordinates and speed along the SVG path
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        const step = 0.0018 * speedMultiplier;
        const next = prev + step;
        if (next >= 1.0) {
          return 0.0; // Loop back or arrival cycle
        }
        return next;
      });
      setTelemetryPulse((p) => (p + 1) % 100);
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, speedMultiplier]);

  // Calculate current bus position & heading angle from SVG path
  const busPosition = useMemo(() => {
    if (!pathRef.current) {
      // Fallback interpolation between first and last waypoint
      const x = 110 + progress * (790 - 110);
      const y = 85 + progress * (395 - 85);
      return { x, y, angle: 30 };
    }

    try {
      const totalLength = pathRef.current.getTotalLength();
      const currentDist = progress * totalLength;
      const pt = pathRef.current.getPointAtLength(currentDist);

      // Tangent for rotation
      const nextDist = Math.min(currentDist + 4, totalLength);
      const nextPt = pathRef.current.getPointAtLength(nextDist);
      const dx = nextPt.x - pt.x;
      const dy = nextPt.y - pt.y;
      const angle = (Math.atan2(dy, dx) * 180) / Math.PI;

      return { x: pt.x, y: pt.y, angle };
    } catch {
      return { x: 450, y: 220, angle: 25 };
    }
  }, [progress]);

  // Determine current active waypoint, next stop, and ETA
  const activeSegment = useMemo(() => {
    // 5 stops divide into 4 intervals
    const idx = Math.min(Math.floor(progress * 4), 3);
    const fromStop = WAYPOINTS[idx];
    const toStop = WAYPOINTS[idx + 1];
    const segmentProgress = (progress * 4) - idx;
    const remainingKm = ((1 - progress) * 11.2).toFixed(1);
    const etaMinutes = Math.max(1, Math.round((1 - progress) * 28));

    // Realistic fluctuating speed
    const baseSpeed = progress > 0.45 && progress < 0.65 ? 28 : 38; // Slower near traffic junction
    const speedVariation = (Math.sin(telemetryPulse * 0.4) * 5);
    const liveSpeed = Math.round(baseSpeed + speedVariation);

    return {
      fromStop,
      toStop,
      segmentProgress,
      remainingKm,
      etaMinutes,
      liveSpeed,
      isNearCampus: progress > 0.88,
    };
  }, [progress, telemetryPulse]);

  return (
    <div className="rounded-3xl bg-white dark:bg-stone-900 border border-orange-200/90 dark:border-amber-950/90 shadow-md overflow-hidden space-y-0 transition-all">
      {/* Top Banner / Telemetry Header */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-orange-50 via-amber-50/60 to-orange-100/40 dark:from-stone-900 dark:via-stone-850 dark:to-stone-900 border-b border-orange-200/80 dark:border-stone-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-orange-600 text-white font-mono text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-xs">
              <Radio className="w-3 h-3 animate-pulse text-amber-200" />
              <span>Live Transit Telemetry</span>
            </span>
            <span className="text-xs font-semibold text-stone-500 dark:text-stone-400">
              • Route 14 North Bengaluru Corridor
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-extrabold text-stone-900 dark:text-stone-100 font-display flex items-center gap-2">
            <span>Route 14 Smart School Bus Live Location</span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono font-bold">
              {route.vehicleNumber}
            </span>
          </h3>

          <p className="text-xs text-stone-600 dark:text-stone-400">
            Real-time GPS satellite positioning, Gate 2 arrival countdown, and passenger safety telemetry.
          </p>
        </div>

        {/* Quick KPI Badges */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="px-3 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 shadow-xs text-xs flex items-center gap-2">
            <Gauge className="w-4 h-4 text-orange-600" />
            <div>
              <span className="text-[10px] text-stone-400 block font-mono uppercase">Speed</span>
              <span className="font-bold font-mono text-stone-900 dark:text-stone-100">
                {activeSegment.liveSpeed} km/h
              </span>
            </div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 shadow-xs text-xs flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-600" />
            <div>
              <span className="text-[10px] text-stone-400 block font-mono uppercase">Campus Gate 2 ETA</span>
              <span className="font-bold font-mono text-orange-600 dark:text-orange-400">
                {activeSegment.etaMinutes} min ({activeSegment.remainingKm} km)
              </span>
            </div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <div>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-mono uppercase">Status</span>
              <span className="font-bold text-emerald-800 dark:text-emerald-200">
                {activeSegment.isNearCampus ? 'Arriving Gate 2' : 'On Schedule'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* SVG Vector Map Container */}
      <div className="relative w-full bg-[#fdfbf7] dark:bg-[#15100c] border-b border-orange-200/70 dark:border-stone-800 overflow-hidden">
        {/* Subtle Map Grid lines */}
        <div className="absolute inset-0 pointer-events-none opacity-40 dark:opacity-20 bg-[radial-gradient(#ea580c_1px,transparent_1px)] [background-size:24px_24px]" />

        {/* Floating Telemetry Overlay (Top Left) */}
        <div className="absolute top-4 left-4 z-10 bg-white/90 dark:bg-stone-900/90 backdrop-blur-md px-3.5 py-2.5 rounded-2xl border border-stone-200/90 dark:border-stone-700/80 shadow-md text-xs space-y-1 max-w-[220px]">
          <div className="flex items-center justify-between text-[11px] font-bold">
            <span className="text-stone-500 dark:text-stone-400 font-mono">NEXT STOP</span>
            <span className="text-orange-600 font-mono font-extrabold">{activeSegment.toStop.timeScheduled}</span>
          </div>
          <div className="font-extrabold text-stone-900 dark:text-stone-100 truncate">
            {activeSegment.toStop.shortName}
          </div>
          <div className="text-[10px] text-stone-500 dark:text-stone-400 truncate">
            {activeSegment.toStop.landmark}
          </div>
          <div className="w-full bg-stone-200 dark:bg-stone-700 h-1.5 rounded-full overflow-hidden mt-1">
            <div
              className="bg-orange-600 h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.round(activeSegment.segmentProgress * 100)}%` }}
            />
          </div>
        </div>

        {/* Floating Campus Target Badge (Bottom Right) */}
        <div className="absolute bottom-4 right-4 z-10 bg-gradient-to-r from-orange-600 to-amber-600 text-white px-3.5 py-2 rounded-2xl shadow-lg text-xs flex items-center gap-2">
          <MapPin className="w-4 h-4 text-amber-200 animate-bounce" />
          <div>
            <div className="font-extrabold text-[11px] uppercase tracking-wider text-orange-100">Destination</div>
            <div className="font-bold">Tattvasayam Gate 2</div>
          </div>
        </div>

        {/* Vector SVG Map Viewport */}
        <svg
          viewBox="0 0 900 480"
          className="w-full h-auto min-h-[340px] max-h-[500px] select-none block"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Linear gradient for transit path */}
            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f97316" />
              <stop offset="50%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#c2410c" />
            </linearGradient>

            {/* Glowing filter for bus beacon */}
            <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>

            {/* Water gradient for Jakkur Lake */}
            <linearGradient id="lakeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#0284c7" stopOpacity="0.6" />
            </linearGradient>

            {/* Green park gradient for GKVK / Aerodrome green spaces */}
            <linearGradient id="parkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22c55e" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#16a34a" stopOpacity="0.25" />
            </linearGradient>
          </defs>

          {/* ================= GEOGRAPHIC CONTEXT LAYERS ================= */}

          {/* Green Zones: GKVK Botanical Grounds & Jakkur Aerodrome Flight Strip Buffer */}
          <polygon
            points="180,40 340,30 380,140 220,130"
            fill="url(#parkGradient)"
            stroke="#16a34a"
            strokeWidth="1"
            strokeDasharray="4 4"
            opacity="0.7"
          />
          <text x="240" y="85" fontSize="10" fontWeight="bold" fill="#15803d" opacity="0.8">
            GKVK Agro Campus
          </text>

          <polygon
            points="580,120 760,110 820,220 640,240"
            fill="url(#parkGradient)"
            stroke="#16a34a"
            strokeWidth="1"
            strokeDasharray="4 4"
            opacity="0.7"
          />
          <text x="660" y="170" fontSize="10" fontWeight="bold" fill="#15803d" opacity="0.8">
            Jakkur Aerodrome Runway
          </text>

          {/* Water Body: Jakkur Lake */}
          <path
            d="M 500,340 C 530,320 580,310 630,340 C 670,365 650,420 590,430 C 540,440 480,410 490,370 Z"
            fill="url(#lakeGradient)"
            stroke="#0284c7"
            strokeWidth="1.5"
          />
          <text x="560" y="380" fontSize="11" fontWeight="bold" fill="#0369a1" textAnchor="middle">
            Jakkur Lake (Amruthahalli basin)
          </text>

          {/* Secondary Arterial Roads (Background Network) */}
          {/* Bellary Road / NH 44 corridor */}
          <line x1="80" y1="30" x2="840" y2="280" stroke={isDark ? '#3d2e24' : '#e2d8cd'} strokeWidth="12" strokeLinecap="round" />
          <line x1="80" y1="30" x2="840" y2="280" stroke={isDark ? '#261b14' : '#fff'} strokeWidth="2" strokeDasharray="6 6" />
          <text x="730" y="240" fontSize="9" fontWeight="bold" fill={isDark ? '#8c786a' : '#a89a8d'} transform="rotate(18, 730, 240)">
            Bellary Rd / NH 44
          </text>

          {/* Outer Ring Road Link */}
          <line x1="420" y1="40" x2="490" y2="450" stroke={isDark ? '#36281e' : '#ede5db'} strokeWidth="8" strokeLinecap="round" />
          <text x="440" y="430" fontSize="8" fontWeight="bold" fill={isDark ? '#7a6759' : '#b0a396'}>
            Sahakar Nagar 14th Main
          </text>

          {/* Jakkur Plantation Road into Academy */}
          <line x1="600" y1="280" x2="830" y2="440" stroke={isDark ? '#47362a' : '#ded1c2'} strokeWidth="10" strokeLinecap="round" />
          <text x="730" y="350" fontSize="9" fontWeight="bold" fill={isDark ? '#9a8575' : '#8c7b6c'} transform="rotate(32, 730, 350)">
            Plantation Rd
          </text>

          {/* ================= ROUTE 14 TRANSIT PATH ================= */}

          {/* Outer Glow Halo for Route */}
          <path
            d={ROUTE_SVG_PATH}
            fill="none"
            stroke="#ea580c"
            strokeWidth="10"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity="0.2"
          />

          {/* Main Transit Highway Ribbon */}
          <path
            d={ROUTE_SVG_PATH}
            fill="none"
            stroke="url(#routeGradient)"
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Hidden reference path for exact mathematical getPointAtLength */}
          <path ref={pathRef} d={ROUTE_SVG_PATH} fill="none" stroke="transparent" strokeWidth="1" />

          {/* Dashed animated flow pulse along the route */}
          <path
            d={ROUTE_SVG_PATH}
            fill="none"
            stroke="#fed7aa"
            strokeWidth="2"
            strokeDasharray="8 12"
            strokeLinecap="round"
            className="animate-pulse"
          />

          {/* ================= 5 ROUTE WAYPOINTS / BUS STOPS ================= */}
          {WAYPOINTS.map((wp) => {
            const isSelected = selectedWaypoint?.id === wp.id;
            const isDestination = wp.id === 5;
            const isOrigin = wp.id === 1;

            return (
              <g
                key={wp.id}
                className="cursor-pointer transition-transform hover:scale-110"
                onClick={() => setSelectedWaypoint(wp)}
              >
                {/* Clickable hit area */}
                <circle cx={wp.x} cy={wp.y} r="24" fill="transparent" />

                {/* Outer ripple if selected */}
                {isSelected && (
                  <circle
                    cx={wp.x}
                    cy={wp.y}
                    r="18"
                    fill="none"
                    stroke="#ea580c"
                    strokeWidth="2"
                    strokeDasharray="3 3"
                    className="animate-spin"
                  />
                )}

                {/* Stop marker base */}
                <circle
                  cx={wp.x}
                  cy={wp.y}
                  r={isDestination ? 12 : 9}
                  fill={isDestination ? '#ea580c' : isOrigin ? '#f59e0b' : '#ffffff'}
                  stroke={isDestination ? '#ffffff' : '#ea580c'}
                  strokeWidth={isDestination ? 3 : 2.5}
                  filter="drop-shadow(0px 2px 4px rgba(0,0,0,0.15))"
                />

                {/* Inner dot */}
                {!isDestination && (
                  <circle cx={wp.x} cy={wp.y} r="4" fill="#ea580c" />
                )}

                {/* Stop Number / Icon indicator */}
                {isDestination && (
                  <text
                    x={wp.x}
                    y={wp.y + 3.5}
                    fontSize="9"
                    fontWeight="bold"
                    fill="#ffffff"
                    textAnchor="middle"
                  >
                    ★
                  </text>
                )}

                {/* Stop Label Banner */}
                <g transform={`translate(${wp.x}, ${wp.y + (wp.id % 2 === 0 ? -18 : 22)})`}>
                  <rect
                    x="-65"
                    y="-11"
                    width="130"
                    height="20"
                    rx="10"
                    fill={isSelected ? '#ea580c' : isDark ? '#261b14' : '#ffffff'}
                    stroke={isSelected ? '#ea580c' : isDark ? '#47362a' : '#fed7aa'}
                    strokeWidth="1.2"
                    filter="drop-shadow(0px 1px 3px rgba(0,0,0,0.1))"
                  />
                  <text
                    x="0"
                    y="3"
                    fontSize="9.5"
                    fontWeight="bold"
                    fill={isSelected ? '#ffffff' : isDark ? '#fed7aa' : '#7c2d12'}
                    textAnchor="middle"
                  >
                    {wp.shortName}
                  </text>
                </g>
              </g>
            );
          })}

          {/* ================= REAL-TIME SIMULATED BUS BEACON ================= */}
          <g
            transform={`translate(${busPosition.x}, ${busPosition.y}) rotate(${busPosition.angle})`}
            filter="url(#glow)"
          >
            {/* Pulsing GPS Radar Wave */}
            <circle cx="0" cy="0" r="16" fill="#ea580c" opacity="0.25" className="animate-ping" />
            <circle cx="0" cy="0" r="11" fill="#ea580c" opacity="0.4" />

            {/* School Bus Vehicle Glyph */}
            <g transform="translate(-14, -8)">
              {/* Bus Chassis (Yellow-Orange school bus) */}
              <rect x="0" y="0" width="28" height="16" rx="4" fill="#f59e0b" stroke="#78350f" strokeWidth="1.5" />
              {/* Front windshield */}
              <rect x="20" y="2" width="5" height="12" rx="1.5" fill="#38bdf8" />
              {/* Side passenger windows */}
              <rect x="5" y="2" width="4" height="4" rx="1" fill="#0f172a" />
              <rect x="11" y="2" width="4" height="4" rx="1" fill="#0f172a" />
              <rect x="5" y="10" width="4" height="4" rx="1" fill="#0f172a" />
              <rect x="11" y="10" width="4" height="4" rx="1" fill="#0f172a" />
              {/* Headlights */}
              <circle cx="26" cy="3" r="1.5" fill="#fef08a" />
              <circle cx="26" cy="13" r="1.5" fill="#fef08a" />
              {/* Route 14 insignia */}
              <text x="11" y="9.5" fontSize="5" fontWeight="black" fill="#78350f" textAnchor="middle">
                14
              </text>
            </g>
          </g>

          {/* Compass Rose Indicator */}
          <g transform="translate(840, 50)" opacity="0.7">
            <circle cx="0" cy="0" r="16" fill={isDark ? '#261b14' : '#ffffff'} stroke="#ea580c" strokeWidth="1" />
            <line x1="0" y1="-12" x2="0" y2="12" stroke="#ea580c" strokeWidth="1.5" />
            <line x1="-12" y1="0" x2="12" y2="0" stroke="#fed7aa" strokeWidth="1.5" />
            <polygon points="0,-14 -3,-6 3,-6" fill="#ea580c" />
            <text x="0" y="-17" fontSize="7" fontWeight="bold" fill="#ea580c" textAnchor="middle">
              N
            </text>
          </g>
        </svg>
      </div>

      {/* Interactive Controls & Selected Stop Inspection Drawer */}
      <div className="p-5 sm:p-6 bg-white dark:bg-stone-900 grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Stop Inspector / Student Roster (5 cols) */}
        <div className="lg:col-span-5 p-4 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800 space-y-3">
          <div className="flex items-center justify-between border-b border-stone-200/80 dark:border-stone-700/80 pb-2.5">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-orange-600" />
              <h4 className="font-extrabold text-xs uppercase tracking-wider text-stone-700 dark:text-stone-300">
                Selected Waypoint Details
              </h4>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-orange-100 dark:bg-stone-800 text-orange-700 dark:text-orange-300 font-bold">
              Stop {selectedWaypoint?.id} of 5
            </span>
          </div>

          {selectedWaypoint ? (
            <div className="space-y-2.5 text-xs">
              <div>
                <span className="text-base font-extrabold text-stone-900 dark:text-stone-100 block">
                  {selectedWaypoint.name}
                </span>
                <span className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                  <Navigation className="w-3 h-3 text-stone-400" />
                  <span>{selectedWaypoint.landmark}</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-750">
                  <span className="text-[10px] text-stone-400 block uppercase">Scheduled Time</span>
                  <span className="font-bold text-stone-900 dark:text-stone-100">{selectedWaypoint.timeScheduled}</span>
                </div>
                <div className="p-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-750">
                  <span className="text-[10px] text-stone-400 block uppercase">Transit Zone</span>
                  <span className="font-bold text-orange-600">{selectedWaypoint.zone}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-stone-200/80 dark:border-stone-700/80">
                <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block mb-1">
                  Enrolled Scholars at this Stop:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedWaypoint.studentsBoarding.map((student, i) => (
                    <span
                      key={i}
                      className="px-2 py-1 rounded-lg bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200 text-[11px] font-medium flex items-center gap-1"
                    >
                      <Users className="w-3 h-3 text-orange-500" />
                      <span>{student}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-stone-400 text-xs">
              Click any stop on the map to inspect details
            </div>
          )}
        </div>

        {/* Right: Simulation Controls & Driver / Dispatch Telemetry (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
          {/* Driver & Safety Card */}
          <div className="p-4 rounded-2xl bg-orange-50/60 dark:bg-stone-850/60 border border-orange-200/70 dark:border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-stone-900 dark:text-stone-100">
                  Driver: {route.driverName}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                  Verified License
                </span>
              </div>
              <p className="text-[11px] text-stone-500">
                Contact: <span className="font-mono">{route.driverPhone}</span> • Speed governor capped at 40 km/h
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <a
                href={`tel:${route.driverPhone}`}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:bg-orange-50 font-bold text-stone-800 dark:text-stone-200 transition flex items-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-stone-500" />
                <span>Call Cabin</span>
              </a>

              {onNavigateToParentPortal && (
                <button
                  onClick={onNavigateToParentPortal}
                  className="px-3 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold transition shadow-xs flex items-center gap-1"
                >
                  <span>Parent Portal</span>
                  <span>&rarr;</span>
                </button>
              )}
            </div>
          </div>

          {/* Real-Time Simulation Interactive Scrubber & Speed Controls */}
          <div className="p-4 rounded-2xl bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-orange-600" />
                <span>Route 14 Live Movement Simulator</span>
              </span>
              <span className="font-mono text-[11px] text-stone-500">
                Progress: {Math.round(progress * 100)}%
              </span>
            </div>

            {/* Scrubber slider */}
            <input
              type="range"
              min="0"
              max="1"
              step="0.005"
              value={progress}
              onChange={(e) => setProgress(parseFloat(e.target.value))}
              className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-orange-600"
            />

            {/* Playback Controls & Speed Toggle Buttons */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
                    isPlaying
                      ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 hover:bg-amber-200'
                      : 'bg-orange-600 text-white hover:bg-orange-700 shadow-xs'
                  }`}
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlaying ? 'Pause' : 'Resume Telemetry'}</span>
                </button>

                <button
                  onClick={() => setProgress(0.0)}
                  className="px-2.5 py-1.5 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-300 font-semibold flex items-center gap-1"
                  title="Reset to Yelahanka origin"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restart</span>
                </button>

                <button
                  onClick={() => setProgress(0.85)}
                  className="px-2.5 py-1.5 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-300 font-semibold"
                  title="Jump to Gate 2 Arrival"
                >
                  Jump Gate 2
                </button>
              </div>

              {/* Speed Multipliers */}
              <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 p-1 rounded-xl">
                {([1, 2, 4] as const).map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setSpeedMultiplier(spd)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold font-mono transition ${
                      speedMultiplier === spd
                        ? 'bg-white dark:bg-stone-700 text-orange-600 shadow-xs'
                        : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
